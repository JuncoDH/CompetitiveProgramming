The tests
   27_extra.in, 28_extra.in, 29_extra.in and 30_extra.in 
have been added after the SWERC contest.
