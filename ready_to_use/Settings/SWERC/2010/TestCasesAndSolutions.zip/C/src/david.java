import java.lang.*;
import java.util.*;
import java.io.*;
import static java.lang.Math.*;

public class david {
  int n;
  int[][][] matrix;
  Random rand = new Random();

  public boolean readInput(BufferedReader in) throws IOException {
    StringTokenizer st = new StringTokenizer(in.readLine());
    n = Integer.parseInt(st.nextToken());
    if (n == 0) return false;

    matrix = new int[2][n][n];
    for (int i = 0; i < 2; ++i)
      for (int y = 0; y < n; ++y) {
        st = new StringTokenizer(in.readLine());
        for (int x = 0; x < n; ++x)
          matrix[i][y][x] = Integer.parseInt(st.nextToken());
      }
    in.readLine();
    return true;
  }

  double[] mult(int m, double[] x) {
    double[] y = new double[n];
    for (int i = 0; i < n; ++i)
      for (int j = 0; j < n; ++j)
        y[i] += matrix[m][i][j] * x[j];
    return y;
  }

  public void solve(PrintWriter out) {
    double[] x = new double[n];
    for (int i = 0; i < n; ++i)
      x[i] = rand.nextDouble();

    double[] a = mult(0, mult(0, x)),
             b = mult(1, x);
    double dist = 0;
    for (int i = 0; i < n; ++i) dist = max(dist, abs(a[i] - b[i]));
    out.println(dist < 1e-5 ? "YES" : "NO");
  }

  public static void main(String[] args) {
    try {
      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      PrintWriter out = new PrintWriter(new OutputStreamWriter(System.out));
      for (;;) {
        david a = new david();
        if (!a.readInput(in)) break;
        a.solve(out);
      }
      out.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
};
