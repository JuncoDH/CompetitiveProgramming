import java.lang.*;
import java.util.*;
import java.io.*;
import static java.lang.Math.*;

public class contest {
  int ly, lx;
  int[] sx, sy;

  boolean readInput(BufferedReader in) throws IOException {
    StringTokenizer st = new StringTokenizer(in.readLine());
    ly = Integer.parseInt(st.nextToken());
    lx = Integer.parseInt(st.nextToken());
    if (ly == 0) return false;

    sy = new int[ly];
    sx = new int[lx];

    st = new StringTokenizer(in.readLine());
    for (int i = 0; i < ly; ++i) sy[i] = Integer.parseInt(st.nextToken());
    st = new StringTokenizer(in.readLine());
    for (int j = 0; j < lx; ++j) sx[j] = Integer.parseInt(st.nextToken());
    in.readLine();
    return true;
  }

  class pii {
    int first, second;
    pii(int f, int s) { first = f; second = s; }
  }

  boolean possible(int pos) {
    int[] sumy = Arrays.copyOf(sy, ly),
          sumx = Arrays.copyOf(sx, lx);
    int i = pos / lx, j = pos % lx;
    for (; i < ly; ++i) {
      Vector<pii> v = new Vector<pii>();
      for (int k = j; k < lx; ++k) if (sumx[k] > 0)
        v.add(new pii(sumx[k], k));
      Collections.sort(v, 
          new Comparator<pii>() {
            public int compare(pii p1, pii p2) {
              if (p1.first > p2.first) return -1;
              else if (p1.first < p2.first) return 1;
              else return p1.second - p2.second;
            }
          }
      );

      for (int k = 0; sumy[i] > 0 && k < v.size(); ++k) {
        --sumx[v.elementAt(k).second];
        --sumy[i];
      }
      if (sumy[i] > 0) return false;
      j = 0;
    }
    for (int k = 0; k < lx; ++k) if (sumx[k] > 0) return false;
    return true;
  }

  public void solve(PrintWriter out, boolean first) {
    if (!first) out.println();

    if (!possible(0)) out.println("Impossible");
    else {
      for (int n = 0; n < ly * lx; ++n) {
        if (!possible(n + 1)) {
          int y = n / lx, x = n % lx;
          --sy[y]; --sx[x];
          out.print("Y");
        } else out.print("N");
        if (n % lx == lx - 1) out.println("");
      }
    }
  }

  public static void main(String[] args) {
    boolean first = true;
    try {
      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      PrintWriter out = new PrintWriter(new OutputStreamWriter(System.out));
      for (;;) {
        contest a = new contest();
        if (!a.readInput(in)) break;
        a.solve(out, first);
        first = false;
      }
      out.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
