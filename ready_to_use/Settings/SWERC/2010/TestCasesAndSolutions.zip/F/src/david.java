// O(n^2 2^n) solution to monkey, simplest version.
// David Garcia Soriano.
import java.lang.*;
import java.util.*;
import java.io.*;
import static java.lang.Math.*;

public class david {
  int n;
  int[] dist, shoot, prev, edge;

  public boolean readInput(BufferedReader in) throws IOException {
    StringTokenizer st = new StringTokenizer(in.readLine());
    n = Integer.parseInt(st.nextToken());
    int m = Integer.parseInt(st.nextToken());
    if (n == 0) return false;

    dist = new int[1 << n];
    shoot = new int[1 << n];
    prev = new int[1 << n];
    edge = new int[n];

    for (int i = 0; i < m; ++i) {
      st = new StringTokenizer(in.readLine());
      int a = Integer.parseInt(st.nextToken()),
          b = Integer.parseInt(st.nextToken());
      edge[a] |= 1 << b;
      edge[b] |= 1 << a;
    }
    in.readLine();
    return true;
  }

  public void solve(PrintWriter out) {
    Arrays.fill(dist, -1);
    Deque<Integer> q = new ArrayDeque<Integer>();
    q.addLast((1 << n) - 1);
    dist[(1 << n) - 1] = 0;

    while (dist[0] < 0 && q.size() > 0) {
      int s = q.pollFirst(), d = dist[s];
      for (int i = 0; i < n; ++i) if ((s & (1 << i)) != 0) {
        int t = 0;
        for (int j = 0; j < n; ++j) if ((i != j) && ((s & (1 << j)) != 0))
          t |= edge[j];
        if (dist[t] < 0) {
          dist[t] = d + 1;
          shoot[t] = i;
          prev[t] = s;
          q.addLast(t);
        }
      }
    }

    if (dist[0] < 0) out.println("Impossible");
    else {
      out.print(dist[0] + ":");
      Vector<Integer> path = new Vector<Integer>();
      int s = 0;
      while (s != ((1 << n) - 1)) {
        path.add(shoot[s]);
        s = prev[s];
      }
      for (int i = path.size() - 1; i >= 0; --i)
        out.print(" " + path.elementAt(i));
      out.println();
    }
  }

  public static void main(String[] args) {
    try {
      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      PrintWriter out = new PrintWriter(new OutputStreamWriter(System.out));
      for (;;) {
        david a = new david();
        if (!a.readInput(in)) break;
        a.solve(out);
      }
      out.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
