import java.lang.*;
import java.util.*;
import java.io.*;
import static java.lang.Math.*;

public class david {
  static final int infinity = 1000000000;

  class Edge {
    int a, b, cost;
    Edge(int aa, int bb, int c) { a = aa; b = bb; cost = c; }
    int endpoint(int from) { return a + b - from; }
  };

  Vector<Edge>[] adj;
  Edge[] last_edge, all_edges;
  boolean[] visited;
  int n, numedges;

  void dfs(int a, int b) {
    visited[a] = true;
    if (a != b)
      for (Edge e: adj[a]) {
        int v = e.endpoint(a);
        if (!visited[v]) {
          last_edge[v] = e;
          dfs(v, b);
        }
      }
  }

  boolean readInput(BufferedReader in) throws IOException {
    StringTokenizer st = new StringTokenizer(in.readLine());
    n = Integer.parseInt(st.nextToken());
    if (n == 0) return false;

    st = new StringTokenizer(in.readLine());
    numedges = Integer.parseInt(st.nextToken());

    all_edges = new Edge[numedges];
    last_edge = new Edge[n];
    visited = new boolean[n];

    for (int i = 0; i < numedges; ++i) {
      st = new StringTokenizer(in.readLine());
      int a = Integer.parseInt(st.nextToken()),
          b = Integer.parseInt(st.nextToken()),
          cost = Integer.parseInt(st.nextToken());
      all_edges[i] = new Edge(a, b, cost); // a != b
    }

    in.readLine();
    return true;
  }

  void solve(PrintWriter out) {
    Arrays.sort(all_edges, 
        new Comparator<Edge>() {
          public int compare(Edge a, Edge b) {
            return a.cost - b.cost;
          }
        }
    );

    LinkedList<Edge> current = new LinkedList<Edge>();
    int ret = infinity, 
        intree = 1;    // 1 + number of vertices in the current forest
    for (Edge e: all_edges) {
      // Build adjacency list
      adj = (Vector<Edge>[]) new Vector[n];
      for (int i = 0; i < n; ++i) adj[i] = new Vector<Edge>();

      for (Edge g: current) {
        adj[g.a].add(g);
        adj[g.b].add(g);
      }

      // Find the path between e->a and e->b or determine that no such path exists
      Arrays.fill(visited, false);
      dfs(e.a, e.b);
      if (!visited[e.b]) {
        ++intree;
        current.add(e);
      } else {
        // Need to remove the lightest edge in the path
        int v = e.b, bestv = -1, cost = infinity;
        while (v != e.a) {
          if (bestv < 0 || last_edge[v].cost < cost) {
            cost = last_edge[v].cost;
            bestv = v;
          }
          v = last_edge[v].endpoint(v);
        }
        current.remove(last_edge[bestv]);
        current.add(e);
      }

      if (intree == n)
        ret = min(ret, current.getLast().cost - current.getFirst().cost);
    }
    out.println(ret);
  }

  public static void main(String[] args) {
    boolean first = true;
    try {
      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      PrintWriter out = new PrintWriter(new OutputStreamWriter(System.out));
      for (;;) {
        david a = new david();
        if (!a.readInput(in)) break;
        a.solve(out);
      }
      out.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
