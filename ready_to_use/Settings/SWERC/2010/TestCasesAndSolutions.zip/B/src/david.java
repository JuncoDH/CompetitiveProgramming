import java.lang.*;
import java.util.*;
import java.io.*;
import static java.lang.Math.*;

public class david {
  int m, n, mod;
  long[] a;

  long[][] multiply(int m, long[][] a, long[][] b) {
    long[][] c = new long[m][m];
    for (int i = 0; i < m; ++i)
      for (int j = 0; j < m; ++j)
        for (int k = 0; k < m; ++k)
          c[i][j] = (c[i][j] + a[i][k] * b[k][j]) % mod;
    return c;
  }

  class pii {
    public int left, right;
    public pii(int l, int r) { left = l; right = r; }
  }

  pii next(int left, int right, int l, int r) {
    if (left < 0) left = l; else if (left > 0) left = r;
    if (right > 0) right = r; else if (right < 0) right = l;
    return new pii(left, right);
  }

  boolean readInput(BufferedReader in) throws IOException {
    StringTokenizer st = new StringTokenizer(in.readLine());
    m = Integer.parseInt(st.nextToken());
    if (m == 0) return false;

    st = new StringTokenizer(in.readLine());
    a = new long[m + 1];
    for (int i = 0; i <= m; ++i)
      a[i] = (long)Integer.parseInt(st.nextToken());

    st = new StringTokenizer(in.readLine());
    n = Integer.parseInt(st.nextToken());
    mod = Integer.parseInt(st.nextToken());
    in.readLine();

    return true;
  }

  void solve(PrintWriter out) {
    long[][] mat = new long[m][m];
    for (int i = 0; i < m; ++i)
      for (int j = (int)min(a[i], a[i + 1]); j < (int)max(a[i], a[i + 1]); ++j)
        mat[j][i] = 1;

    long[][] ret = new long[m][m];
    for (int i = 0; i < m; ++i) ret[i][i] = 1;

    for (int t = 1; t <= n; t *= 2) {
      if ((n & t) != 0) ret = multiply(m, ret, mat);
      mat = multiply(m, mat, mat);
    }

    long total = 0;
    for (int i = 0; i < m; ++i)
      total = (total + ret[i][i]) % mod;

    int s[][] = new int[m + 1][2];
    for (int i = 0; i <= m; ++i) {
      s[i][0] = i > 0 ? (int)Long.signum(a[i - 1] - a[i]) : 0;
      s[i][1] = i < m ? (int)Long.signum(a[i + 1] - a[i]) : 0; 
    }

    boolean inf = false;
    for (int i = 0; i <= m && !inf; ++i) {
      int x = i;
      int sx[] = new int[]{ -1, 1 };
      boolean can_inf = true;
      for (int j = 0; j < n; ++j) {
        if (sx[1] > 0)      can_inf &= x < m && (abs(a[x + 1] - a[x]) == 1);
        else if (sx[1] < 0) can_inf &= x > 0 && (abs(a[x - 1] - a[x]) == 1);
        else can_inf = false;

        pii p = next(sx[0], sx[1], s[x][0], s[x][1]);
        sx[0] = p.left; sx[1] = p.right;
        x = (int)a[x];
      }

      if (x == i) {
        ++total;
        if (sx[0] < 0) --total;   // left decreasing, already included in [i - 1, i]
        if (sx[1] > 0) --total;   // right increasing, already included in [i, i + 1]
        if (i < m && sx[1] > 0 && can_inf) inf = true;
        if (total < 0) total += mod;
      }
    }

    if (inf) out.println("Infinity");
    else out.println(total % mod);
  }

  public static void main(String[] args) {
    boolean first = true;
    try {
      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      PrintWriter out = new PrintWriter(new OutputStreamWriter(System.out));
      for (;;) {
        david a = new david();
        if (!a.readInput(in)) break;
        a.solve(out);
      }
      out.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
