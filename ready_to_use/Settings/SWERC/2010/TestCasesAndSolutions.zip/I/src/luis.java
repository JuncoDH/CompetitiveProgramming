import java.lang.*;
import java.util.*;
import java.io.*;
import static java.lang.Math.*;

public class luis {
  class vertex {
    int par, door;
    Vector<Integer> ch, key;
  };

  int v, c, root, finish;
  int[] wdoor, wkey;
  int[][] adj;
  vertex[] g;

  Vector<Integer> path;

  void buildtree (int vert, int parent){
    g[vert].par = parent;
    for (int i = 0; i < v; i++)
     if (adj[vert][i] >= 0 && i != parent){
       g[vert].ch.add(i);
       buildtree(i, vert);
       if (adj[vert][i] >= 1) {
         g[i].door = adj[vert][i] - 1;
         wdoor[g[i].door] = i;
       }
     }  
   return;
  }

  Vector <Integer> build_path (int ver){
    Vector <Integer> w = new Vector<Integer>();
    while (ver != root){
      w.add(ver);
      ver = g[ver].par;
    }
    w.add(root);
    return w;
  }

  void add_path (Vector <Integer> ret, int start, int end){
    Vector <Integer> first, second;
    first = build_path(start);
    second = build_path(end);
    Collections.reverse(second);
    first.remove(0);
    second.remove(0);
    ret.addAll(first);
    ret.addAll(second);
  }

  boolean readInput(BufferedReader in) throws IOException {
    int aux, maxtampath = 0;

    StringTokenizer st = new StringTokenizer(in.readLine());
    v = Integer.parseInt(st.nextToken());
    c = Integer.parseInt(st.nextToken());
    root = Integer.parseInt(st.nextToken());
    finish = Integer.parseInt(st.nextToken());
    if (v == 0) return false;

    wdoor = new int[v + 2];
    wkey = new int[v + 2];
    Arrays.fill(wdoor, -1);
    Arrays.fill(wkey, -1);
    adj = new int[v][v];
    for (int i = 0; i < v; ++i)
      for (int j = 0; j < v; ++j)
        adj[i][j] = -1;
    g = new vertex[v];
    for (int i = 0; i < v; ++i) {
      g[i] = new vertex();
      g[i].par = -1;
      g[i].ch = new Vector<Integer>();
      g[i].door = -1;
      g[i].key = new Vector<Integer>();
    }

    st = new StringTokenizer(in.readLine());
    for (int i = 0; i < c; ++i) {
      aux = Integer.parseInt(st.nextToken());
      g[aux].key.add(i);
      wkey[i] = aux;
    }

    for (int i = 0; i < v - 1; i++) {
      st = new StringTokenizer(in.readLine());
      int ea = Integer.parseInt(st.nextToken());
      int eb = Integer.parseInt(st.nextToken());
      aux = Integer.parseInt(st.nextToken());
      adj[ea][eb] = aux + 1;
      adj[eb][ea] = aux + 1;
    }

    in.readLine();
    return true;
  }

  void print(Vector<Integer> path, PrintWriter out) {
    out.print(path.size() + ": " + root);
    boolean first = true;
    for (int v: path) {
      if (first) out.print(v); first = false;
      out.print(" " + v);
    }
    out.println();
  }

  void solve(PrintWriter out) {
   buildtree(root, -1);
   wkey[v + 1] = finish;
   wdoor[v + 1] = finish;

   path = new Vector<Integer>();
   Stack <Integer> pila = new Stack<Integer>(); //en la pila guardare las puertas que me vaya encontrando
   int now = root;
   pila.push(v + 1);
   while (!pila.empty() && pila.size() < v + 2){
     int a = pila.peek();
//System.out.println("procesando puerta: " + a);
     Vector <Integer> c = new Vector<Integer>(), d = new Vector<Integer>();
     int pos = wkey[a];
     int x = pos;
//System.out.println("desde la posicion " + pos);
     while (x != root){      
       if (g[x].door != -1) d.add(g[x].door);
       x = g[x].par;
     }
     if (d.size() == 0) { //no door between a and root
//System.out.println("no hay problema para la puerta: " + a);
       add_path(path, now, pos);
       add_path(path, pos, wdoor[a]);
       pila.pop();
       now = wdoor[a];
       if (a < v) g[now].door = -1;
     }
     else {
       for (int i = 0; i < d.size(); i++)
         pila.push(d.elementAt(i));
     }
   }

   if (pila.size() >= v + 2) out.println("Impossible");
   else {
     out.print(path.size() + ": " + root);
     for (int i = 0; i < path.size(); i++) out.print(" " + path.elementAt(i));
     out.println();
   }
  }

  public static void main(String[] args) {
    boolean first = true;
    try {
      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      PrintWriter out = new PrintWriter(new OutputStreamWriter(System.out));
      for (;;) {
        luis a = new luis();
        if (!a.readInput(in)) break;
        a.solve(out);
      }
      out.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
